import argparse
import base64
import hashlib
import hmac
import html
import json
import mimetypes
import os
import secrets
import shutil
import threading
import time
import urllib.parse
import uuid
from datetime import datetime, timezone
from email.utils import formatdate
from multiprocessing import Process
from pathlib import Path
from typing import Dict, Iterable, Optional, Tuple

import uvicorn
from fastapi import Depends, FastAPI, HTTPException, Request, status
from fastapi.responses import FileResponse, JSONResponse, Response, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field


APP_ROOT = Path(__file__).resolve().parent
STATIC_DIR = APP_ROOT / "static"
DATA_ROOT = Path(os.getenv("DATA_ROOT", "/app/data"))
USERS_FILE = Path(os.getenv("USERS_FILE", "/app/users.json"))

SESSION_COOKIE = "wf_session"
SESSION_TTL_SECONDS = 12 * 60 * 60
CHUNK_SIZE = 1024 * 1024
PBKDF2_ROUNDS = 200_000

users_lock = threading.RLock()
session_lock = threading.RLock()
sessions: Dict[str, Dict[str, object]] = {}


class LoginBody(BaseModel):
    username: str
    password: str


class MkdirBody(BaseModel):
    path: str = ""


class RenameBody(BaseModel):
    old_path: str
    new_path: str


class CreateUserBody(BaseModel):
    username: str = Field(min_length=1, max_length=64)
    password: str = Field(min_length=1, max_length=128)
    is_admin: bool = False


class UpdateUserBody(BaseModel):
    new_username: Optional[str] = Field(default=None, min_length=1, max_length=64)
    new_password: Optional[str] = Field(default=None, min_length=1, max_length=128)
    is_admin: Optional[bool] = None


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def hash_password(password: str) -> str:
    salt = secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, PBKDF2_ROUNDS)
    return f"pbkdf2_sha256${PBKDF2_ROUNDS}${salt.hex()}${digest.hex()}"


def verify_password(password: str, stored_value: str) -> bool:
    if not stored_value:
        return False
    if stored_value.startswith("pbkdf2_sha256$"):
        parts = stored_value.split("$", 3)
        if len(parts) != 4:
            return False
        try:
            rounds = int(parts[1])
            salt = bytes.fromhex(parts[2])
            expected = bytes.fromhex(parts[3])
        except ValueError:
            return False
        actual = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, rounds)
        return hmac.compare_digest(actual, expected)
    return hmac.compare_digest(password, stored_value)


def validate_username(username: str) -> None:
    if not username or len(username) > 64:
        raise HTTPException(status_code=400, detail="用户名长度必须在 1-64 个字符之间")
    forbidden = set('/\\:*?"<>|')
    if any(char in forbidden for char in username):
        raise HTTPException(status_code=400, detail="用户名包含非法字符")
    if ".." in username:
        raise HTTPException(status_code=400, detail="用户名不允许包含 ..")


def ensure_environment() -> None:
    DATA_ROOT.mkdir(parents=True, exist_ok=True)
    USERS_FILE.parent.mkdir(parents=True, exist_ok=True)
    if USERS_FILE.exists():
        return
    default_users = {
        "users": {
            "admin": {
                "password_hash": hash_password("admin123"),
                "is_admin": True,
                "created_at": utc_now_iso(),
            },
            "demo": {
                "password_hash": hash_password("demo123"),
                "is_admin": False,
                "created_at": utc_now_iso(),
            },
        }
    }
    save_users(default_users)
    for username in default_users["users"].keys():
        (DATA_ROOT / username).mkdir(parents=True, exist_ok=True)


def load_users() -> Dict[str, object]:
    with users_lock:
        ensure_environment()
        with USERS_FILE.open("r", encoding="utf-8") as f:
            data = json.load(f)
        if "users" not in data or not isinstance(data["users"], dict):
            raise RuntimeError("users.json 格式错误：缺少 users 字段")
        return data


def save_users(data: Dict[str, object]) -> None:
    with users_lock:
        tmp_path = USERS_FILE.with_suffix(".tmp")
        with tmp_path.open("w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        os.replace(tmp_path, USERS_FILE)


def get_user_record(username: str) -> Optional[Dict[str, object]]:
    users_data = load_users()
    record = users_data["users"].get(username)
    if not isinstance(record, dict):
        return None
    return record


def authenticate_user(username: str, password: str) -> Optional[Dict[str, object]]:
    record = get_user_record(username)
    if not record:
        return None
    stored_value = str(record.get("password_hash") or record.get("password") or "")
    if not verify_password(password, stored_value):
        return None
    return {
        "username": username,
        "is_admin": bool(record.get("is_admin", False)),
    }


def get_user_root(username: str) -> Path:
    root = (DATA_ROOT / username).resolve()
    root.mkdir(parents=True, exist_ok=True)
    return root


def normalize_rel_path(raw_path: str) -> Path:
    raw = (raw_path or "").replace("\\", "/").strip()
    raw = raw.lstrip("/")
    candidate = Path(raw)
    clean = Path()
    for part in candidate.parts:
        if part in ("", "."):
            continue
        if part == "..":
            raise HTTPException(status_code=400, detail="路径不合法")
        clean = clean / part
    return clean


def resolve_user_path(username: str, rel_path: str) -> Tuple[Path, Path]:
    root = get_user_root(username)
    rel = normalize_rel_path(rel_path)
    target = (root / rel).resolve()
    if target != root and root not in target.parents:
        raise HTTPException(status_code=400, detail="路径越界")
    return root, target


def path_to_rel(root: Path, target: Path) -> str:
    rel = target.relative_to(root)
    value = rel.as_posix()
    return "" if value == "." else value


def create_session(username: str) -> str:
    token = secrets.token_urlsafe(32)
    expires_at = int(time.time()) + SESSION_TTL_SECONDS
    with session_lock:
        sessions[token] = {"username": username, "expires_at": expires_at}
    return token


def remove_session(token: str) -> None:
    with session_lock:
        sessions.pop(token, None)


def get_session_from_token(token: str) -> Optional[Dict[str, object]]:
    if not token:
        return None
    now_ts = int(time.time())
    with session_lock:
        payload = sessions.get(token)
        if not payload:
            return None
        if int(payload.get("expires_at", 0)) < now_ts:
            sessions.pop(token, None)
            return None
    username = str(payload.get("username"))
    record = get_user_record(username)
    if not record:
        remove_session(token)
        return None
    return {"username": username, "is_admin": bool(record.get("is_admin", False)), "token": token}


def require_login(request: Request) -> Dict[str, object]:
    token = request.cookies.get(SESSION_COOKIE, "")
    user = get_session_from_token(token)
    if not user:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="请先登录")
    return user


def require_admin(user: Dict[str, object] = Depends(require_login)) -> Dict[str, object]:
    if not bool(user.get("is_admin", False)):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="需要管理员权限")
    return user


def sanitize_filename(raw_name: str) -> str:
    name = urllib.parse.unquote(raw_name or "").strip()
    if not name:
        raise HTTPException(status_code=400, detail="缺少文件名")
    if "/" in name or "\\" in name or ".." in name:
        raise HTTPException(status_code=400, detail="文件名不合法")
    return name


def iter_file_chunks(path: Path) -> Iterable[bytes]:
    with path.open("rb") as f:
        while True:
            chunk = f.read(CHUNK_SIZE)
            if not chunk:
                break
            yield chunk


def build_prop_response(href: str, fs_path: Path) -> str:
    is_dir = fs_path.is_dir()
    display_name = fs_path.name if fs_path.name else "/"
    last_modified = formatdate(fs_path.stat().st_mtime, usegmt=True)
    created = datetime.fromtimestamp(fs_path.stat().st_ctime, tz=timezone.utc).isoformat()
    content_type = ""
    content_length = "0"
    if is_dir:
        resource_type = "<D:collection/>"
    else:
        guessed = mimetypes.guess_type(fs_path.name)[0]
        content_type = html.escape(guessed or "application/octet-stream")
        content_length = str(fs_path.stat().st_size)
        resource_type = ""
    return (
        "<D:response>"
        f"<D:href>{html.escape(href)}</D:href>"
        "<D:propstat><D:prop>"
        f"<D:displayname>{html.escape(display_name)}</D:displayname>"
        f"<D:getlastmodified>{html.escape(last_modified)}</D:getlastmodified>"
        f"<D:creationdate>{html.escape(created)}</D:creationdate>"
        f"<D:getcontentlength>{content_length}</D:getcontentlength>"
        f"<D:getcontenttype>{content_type}</D:getcontenttype>"
        f"<D:resourcetype>{resource_type}</D:resourcetype>"
        "</D:prop><D:status>HTTP/1.1 200 OK</D:status></D:propstat>"
        "</D:response>"
    )


def rel_to_href(rel_path: str, is_dir: bool) -> str:
    rel = rel_path.strip("/")
    if not rel:
        return "/"
    encoded = "/".join(urllib.parse.quote(part) for part in rel.split("/"))
    href = f"/{encoded}"
    if is_dir and not href.endswith("/"):
        href += "/"
    return href


def build_propfind_xml(root: Path, target: Path, depth: str) -> str:
    entries = []
    rel = path_to_rel(root, target)
    entries.append(build_prop_response(rel_to_href(rel, target.is_dir()), target))
    if depth in ("1", "infinity") and target.is_dir():
        for child in sorted(target.iterdir(), key=lambda p: (not p.is_dir(), p.name.lower())):
            child_rel = path_to_rel(root, child)
            entries.append(build_prop_response(rel_to_href(child_rel, child.is_dir()), child))
    return (
        "<?xml version='1.0' encoding='utf-8'?>"
        "<D:multistatus xmlns:D='DAV:'>"
        + "".join(entries)
        + "</D:multistatus>"
    )


def dav_unauthorized() -> Response:
    return Response(
        status_code=status.HTTP_401_UNAUTHORIZED,
        headers={"WWW-Authenticate": "Basic realm=\"WebDAV\"", "Content-Length": "0"},
    )


def parse_destination_path(destination_header: str) -> str:
    if not destination_header:
        raise HTTPException(status_code=400, detail="缺少 Destination 头")
    parsed = urllib.parse.urlparse(destination_header)
    path = urllib.parse.unquote(parsed.path or "")
    return path.lstrip("/")


def authenticate_dav_request(request: Request) -> Optional[Dict[str, object]]:
    auth_header = request.headers.get("Authorization", "")
    if not auth_header.lower().startswith("basic "):
        return None
    try:
        encoded = auth_header.split(" ", 1)[1]
        raw = base64.b64decode(encoded).decode("utf-8")
        username, password = raw.split(":", 1)
    except Exception:
        return None
    return authenticate_user(username, password)


ensure_environment()

web_app = FastAPI(title="Fast Web File")
dav_app = FastAPI(title="Fast WebDAV")

if STATIC_DIR.exists():
    web_app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")


@web_app.get("/")
async def page_index() -> Response:
    index_file = STATIC_DIR / "index.html"
    if not index_file.exists():
        raise HTTPException(status_code=404, detail="找不到 static/index.html")
    return FileResponse(index_file)


@web_app.get("/setting.html")
async def page_setting() -> Response:
    setting_file = STATIC_DIR / "setting.html"
    if not setting_file.exists():
        raise HTTPException(status_code=404, detail="找不到 static/setting.html")
    return FileResponse(setting_file)


@web_app.post("/api/login")
async def api_login(body: LoginBody) -> Response:
    user = authenticate_user(body.username, body.password)
    if not user:
        raise HTTPException(status_code=401, detail="用户名或密码错误")
    token = create_session(body.username)
    payload = {"username": body.username, "is_admin": bool(user["is_admin"])}
    response = JSONResponse(payload)
    response.set_cookie(
        SESSION_COOKIE,
        token,
        max_age=SESSION_TTL_SECONDS,
        httponly=True,
        samesite="lax",
    )
    return response


@web_app.post("/api/logout")
async def api_logout(request: Request) -> Response:
    token = request.cookies.get(SESSION_COOKIE, "")
    if token:
        remove_session(token)
    response = JSONResponse({"ok": True})
    response.delete_cookie(SESSION_COOKIE)
    return response


@web_app.get("/api/me")
async def api_me(user: Dict[str, object] = Depends(require_login)) -> Dict[str, object]:
    return {"username": user["username"], "is_admin": bool(user["is_admin"])}


@web_app.get("/api/files")
async def api_files(path: str = "", user: Dict[str, object] = Depends(require_login)) -> Dict[str, object]:
    root, target = resolve_user_path(str(user["username"]), path)
    if not target.exists() or not target.is_dir():
        raise HTTPException(status_code=404, detail="目录不存在")

    items = []
    for entry in sorted(target.iterdir(), key=lambda p: (not p.is_dir(), p.name.lower())):
        stat = entry.stat()
        items.append(
            {
                "name": entry.name,
                "path": path_to_rel(root, entry),
                "is_dir": entry.is_dir(),
                "size": stat.st_size if entry.is_file() else 0,
                "modified_at": datetime.fromtimestamp(stat.st_mtime, tz=timezone.utc).isoformat(),
            }
        )

    parent = ""
    rel_current = path_to_rel(root, target)
    if rel_current:
        parent = str(Path(rel_current).parent).replace("\\", "/")
        if parent == ".":
            parent = ""
    return {"current": rel_current, "parent": parent, "items": items}


@web_app.post("/api/mkdir")
async def api_mkdir(body: MkdirBody, user: Dict[str, object] = Depends(require_login)) -> Dict[str, object]:
    _, target = resolve_user_path(str(user["username"]), body.path)
    target.mkdir(parents=True, exist_ok=True)
    return {"ok": True}


@web_app.post("/api/rename")
async def api_rename(body: RenameBody, user: Dict[str, object] = Depends(require_login)) -> Dict[str, object]:
    _, source = resolve_user_path(str(user["username"]), body.old_path)
    _, destination = resolve_user_path(str(user["username"]), body.new_path)
    if not source.exists():
        raise HTTPException(status_code=404, detail="源路径不存在")
    if destination.exists():
        raise HTTPException(status_code=409, detail="目标路径已存在")
    destination.parent.mkdir(parents=True, exist_ok=True)
    source.rename(destination)
    return {"ok": True}


@web_app.delete("/api/delete")
async def api_delete(path: str, user: Dict[str, object] = Depends(require_login)) -> Dict[str, object]:
    root, target = resolve_user_path(str(user["username"]), path)
    if target == root:
        raise HTTPException(status_code=400, detail="不能删除用户根目录")
    if not target.exists():
        raise HTTPException(status_code=404, detail="路径不存在")
    if target.is_dir():
        shutil.rmtree(target)
    else:
        target.unlink(missing_ok=True)
    return {"ok": True}


@web_app.post("/api/upload")
async def api_upload(request: Request, dir: str = "", user: Dict[str, object] = Depends(require_login)) -> Dict[str, object]:
    username = str(user["username"])
    filename = sanitize_filename(request.headers.get("X-Filename", ""))
    _, target_dir = resolve_user_path(username, dir)
    target_dir.mkdir(parents=True, exist_ok=True)

    final_path = (target_dir / filename).resolve()
    user_root = get_user_root(username)
    if final_path != user_root and user_root not in final_path.parents:
        raise HTTPException(status_code=400, detail="路径越界")

    tmp_path = final_path.with_suffix(final_path.suffix + f".upload-{uuid.uuid4().hex}")
    total = 0
    try:
        with tmp_path.open("wb") as f:
            async for chunk in request.stream():
                if not chunk:
                    continue
                f.write(chunk)
                total += len(chunk)
        os.replace(tmp_path, final_path)
    finally:
        if tmp_path.exists():
            tmp_path.unlink(missing_ok=True)

    return {"ok": True, "file": filename, "bytes": total}


@web_app.get("/api/download")
async def api_download(path: str, user: Dict[str, object] = Depends(require_login)) -> Response:
    _, target = resolve_user_path(str(user["username"]), path)
    if not target.exists() or not target.is_file():
        raise HTTPException(status_code=404, detail="文件不存在")
    quoted = urllib.parse.quote(target.name)
    headers = {
        "Content-Length": str(target.stat().st_size),
        "Content-Disposition": f"attachment; filename*=UTF-8''{quoted}",
    }
    media_type = mimetypes.guess_type(target.name)[0] or "application/octet-stream"
    return StreamingResponse(iter_file_chunks(target), media_type=media_type, headers=headers)


@web_app.get("/api/admin/users")
async def api_admin_users(_: Dict[str, object] = Depends(require_admin)) -> Dict[str, object]:
    users_data = load_users()
    result = []
    for username, record in sorted(users_data["users"].items(), key=lambda item: item[0].lower()):
        result.append(
            {
                "username": username,
                "is_admin": bool(record.get("is_admin", False)),
                "created_at": record.get("created_at", ""),
            }
        )
    return {"users": result}


@web_app.post("/api/admin/users")
async def api_admin_create_user(body: CreateUserBody, _: Dict[str, object] = Depends(require_admin)) -> Dict[str, object]:
    validate_username(body.username)
    users_data = load_users()
    if body.username in users_data["users"]:
        raise HTTPException(status_code=409, detail="用户名已存在")
    users_data["users"][body.username] = {
        "password_hash": hash_password(body.password),
        "is_admin": bool(body.is_admin),
        "created_at": utc_now_iso(),
    }
    save_users(users_data)
    get_user_root(body.username)
    return {"ok": True}


@web_app.put("/api/admin/users/{username}")
async def api_admin_update_user(
    username: str,
    body: UpdateUserBody,
    current_user: Dict[str, object] = Depends(require_admin),
) -> Dict[str, object]:
    users_data = load_users()
    users_map = users_data["users"]
    if username not in users_map:
        raise HTTPException(status_code=404, detail="用户不存在")

    validate_username(username)
    record = users_map[username]
    target_name = username
    if body.new_username and body.new_username != username:
        validate_username(body.new_username)
        if body.new_username in users_map:
            raise HTTPException(status_code=409, detail="新用户名已存在")
        target_name = body.new_username

    if body.new_password:
        record["password_hash"] = hash_password(body.new_password)
        record.pop("password", None)

    if body.is_admin is not None:
        if username == str(current_user["username"]) and not body.is_admin:
            admin_count = sum(1 for item in users_map.values() if bool(item.get("is_admin", False)))
            if admin_count <= 1:
                raise HTTPException(status_code=400, detail="至少保留一个管理员")
        record["is_admin"] = bool(body.is_admin)

    if target_name != username:
        users_map[target_name] = record
        del users_map[username]
        old_dir = DATA_ROOT / username
        new_dir = DATA_ROOT / target_name
        if old_dir.exists():
            if new_dir.exists():
                raise HTTPException(status_code=409, detail="目标目录已存在")
            old_dir.rename(new_dir)
        if str(current_user["username"]) == username:
            current_user["username"] = target_name
    save_users(users_data)
    return {"ok": True, "username": target_name}


@web_app.delete("/api/admin/users/{username}")
async def api_admin_delete_user(
    username: str,
    purge_data: bool = True,
    current_user: Dict[str, object] = Depends(require_admin),
) -> Dict[str, object]:
    if username == str(current_user["username"]):
        raise HTTPException(status_code=400, detail="不能删除当前登录管理员")
    users_data = load_users()
    users_map = users_data["users"]
    if username not in users_map:
        raise HTTPException(status_code=404, detail="用户不存在")
    if bool(users_map[username].get("is_admin", False)):
        admin_count = sum(1 for item in users_map.values() if bool(item.get("is_admin", False)))
        if admin_count <= 1:
            raise HTTPException(status_code=400, detail="至少保留一个管理员")

    del users_map[username]
    save_users(users_data)

    user_dir = DATA_ROOT / username
    if purge_data and user_dir.exists():
        shutil.rmtree(user_dir)

    with session_lock:
        expired_tokens = [
            token for token, payload in sessions.items() if str(payload.get("username", "")) == username
        ]
        for token in expired_tokens:
            sessions.pop(token, None)

    return {"ok": True}


@dav_app.api_route(
    "/{req_path:path}",
    methods=["OPTIONS", "PROPFIND", "GET", "HEAD", "PUT", "DELETE", "MKCOL", "MOVE", "COPY", "LOCK", "UNLOCK"],
)
async def dav_handler(req_path: str, request: Request) -> Response:
    user = authenticate_dav_request(request)
    if not user:
        return dav_unauthorized()
    username = str(user["username"])
    method = request.method.upper()

    root, target = resolve_user_path(username, req_path)

    if method == "OPTIONS":
        allow = "OPTIONS, PROPFIND, GET, HEAD, PUT, DELETE, MKCOL, MOVE, COPY, LOCK, UNLOCK"
        return Response(
            status_code=204,
            headers={
                "DAV": "1, 2",
                "Allow": allow,
                "MS-Author-Via": "DAV",
                "Content-Length": "0",
            },
        )

    if method == "PROPFIND":
        if not target.exists():
            raise HTTPException(status_code=404, detail="路径不存在")
        depth = request.headers.get("Depth", "1").lower()
        xml_body = build_propfind_xml(root, target, depth)
        return Response(content=xml_body, status_code=207, media_type="application/xml", headers={"DAV": "1, 2"})

    if method in ("GET", "HEAD"):
        if not target.exists() or not target.is_file():
            raise HTTPException(status_code=404, detail="文件不存在")
        headers = {
            "Content-Length": str(target.stat().st_size),
            "ETag": f"\"{target.stat().st_mtime_ns}-{target.stat().st_size}\"",
            "Last-Modified": formatdate(target.stat().st_mtime, usegmt=True),
        }
        if method == "HEAD":
            return Response(status_code=200, headers=headers)
        media_type = mimetypes.guess_type(target.name)[0] or "application/octet-stream"
        return StreamingResponse(iter_file_chunks(target), media_type=media_type, headers=headers)

    if method == "PUT":
        target.parent.mkdir(parents=True, exist_ok=True)
        existed = target.exists()
        tmp_path = target.with_suffix(target.suffix + f".dav-{uuid.uuid4().hex}")
        try:
            with tmp_path.open("wb") as f:
                async for chunk in request.stream():
                    if not chunk:
                        continue
                    f.write(chunk)
            os.replace(tmp_path, target)
        finally:
            if tmp_path.exists():
                tmp_path.unlink(missing_ok=True)
        return Response(status_code=204 if existed else 201)

    if method == "MKCOL":
        if target.exists():
            raise HTTPException(status_code=405, detail="目录已存在")
        if not target.parent.exists():
            raise HTTPException(status_code=409, detail="父目录不存在")
        target.mkdir(parents=False, exist_ok=False)
        return Response(status_code=201)

    if method == "DELETE":
        if target == root:
            raise HTTPException(status_code=403, detail="不能删除根目录")
        if not target.exists():
            raise HTTPException(status_code=404, detail="路径不存在")
        if target.is_dir():
            shutil.rmtree(target)
        else:
            target.unlink(missing_ok=True)
        return Response(status_code=204)

    if method in ("MOVE", "COPY"):
        if not target.exists():
            raise HTTPException(status_code=404, detail="源路径不存在")

        destination = parse_destination_path(request.headers.get("Destination", ""))
        _, dst_path = resolve_user_path(username, destination)
        overwrite = request.headers.get("Overwrite", "T").upper() == "T"

        if dst_path.exists() and not overwrite:
            raise HTTPException(status_code=412, detail="目标已存在且不允许覆盖")
        if not dst_path.parent.exists():
            raise HTTPException(status_code=409, detail="目标父目录不存在")

        existed_before = dst_path.exists()
        if method == "MOVE":
            if dst_path.exists():
                if dst_path.is_dir():
                    shutil.rmtree(dst_path)
                else:
                    dst_path.unlink(missing_ok=True)
            target.rename(dst_path)
        else:
            if target.is_dir():
                if dst_path.exists():
                    shutil.rmtree(dst_path)
                shutil.copytree(target, dst_path)
            else:
                shutil.copy2(target, dst_path)

        return Response(status_code=204 if existed_before else 201)

    if method == "LOCK":
        token = f"opaquelocktoken:{uuid.uuid4()}"
        lock_xml = (
            "<?xml version='1.0' encoding='utf-8'?>"
            "<D:prop xmlns:D='DAV:'><D:lockdiscovery><D:activelock>"
            "<D:locktype><D:write/></D:locktype>"
            "<D:lockscope><D:exclusive/></D:lockscope>"
            "<D:depth>Infinity</D:depth>"
            "<D:owner><D:href>FastWebDAV</D:href></D:owner>"
            f"<D:locktoken><D:href>{html.escape(token)}</D:href></D:locktoken>"
            "</D:activelock></D:lockdiscovery></D:prop>"
        )
        return Response(content=lock_xml, status_code=200, media_type="application/xml", headers={"Lock-Token": token})

    if method == "UNLOCK":
        return Response(status_code=204)

    raise HTTPException(status_code=405, detail="方法不支持")


@web_app.exception_handler(HTTPException)
@dav_app.exception_handler(HTTPException)
async def http_exception_handler(request: Request, exc: HTTPException) -> Response:
    if request.app is dav_app:
        return Response(status_code=exc.status_code, content=str(exc.detail))
    return JSONResponse(status_code=exc.status_code, content={"detail": exc.detail})


def run_web_server(host: str, port: int) -> None:
    uvicorn.run(web_app, host=host, port=port, log_level="info")


def run_dav_server(host: str, port: int) -> None:
    uvicorn.run(dav_app, host=host, port=port, log_level="info")


def run_all_servers(web_host: str, web_port: int, dav_host: str, dav_port: int) -> None:
    dav_process = Process(target=run_dav_server, args=(dav_host, dav_port), daemon=True)
    dav_process.start()
    try:
        run_web_server(web_host, web_port)
    finally:
        if dav_process.is_alive():
            dav_process.terminate()
            dav_process.join(timeout=5)


def main() -> None:
    parser = argparse.ArgumentParser(description="FastAPI + WebDAV 文件服务")
    parser.add_argument("--mode", choices=["all", "web", "dav"], default=os.getenv("SERVICE_MODE", "all"))
    parser.add_argument("--web-host", default=os.getenv("WEB_HOST", "0.0.0.0"))
    parser.add_argument("--web-port", type=int, default=int(os.getenv("WEB_PORT", "8080")))
    parser.add_argument("--dav-host", default=os.getenv("DAV_HOST", "0.0.0.0"))
    parser.add_argument("--dav-port", type=int, default=int(os.getenv("DAV_PORT", "1900")))
    args = parser.parse_args()

    ensure_environment()

    if args.mode == "web":
        run_web_server(args.web_host, args.web_port)
        return
    if args.mode == "dav":
        run_dav_server(args.dav_host, args.dav_port)
        return
    run_all_servers(args.web_host, args.web_port, args.dav_host, args.dav_port)


if __name__ == "__main__":
    main()
